package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private EditText user_field;    //обращаемся к классу, давая название определенному полю
    private Button main_button;     //для удобства названия полям даем такие же, как и id классов
    private TextView result_info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        user_field = findViewById(R.id.user_field);     //обращаемся к полю и внутри нее помещаем метод
        main_button = findViewById(R.id.main_button);   //который помогает найти объект по его id
        result_info = findViewById(R.id.result_info);

        main_button.setOnClickListener(new View.OnClickListener() {
            //благодаря методу setOnClickListener мы можем повесить некий обработчик события на кнопку
            //прописывая ввыделение памяти new View.OnClickListener, мы создаем метод onClick
            @Override
            public void onClick(View view) {
                //метод onClick срабатывает при каждом нажатии на кнопку
                if (user_field.getText().toString().trim().equals(""))
                        //getText() позволяет получить тот текст, что написал пользователь
                        //toString() преобразовывает текст в строку
                        //trim() обрезает у строки лишние пробелы до и после самой строки
                        //equals("") проверяет не равна ли строка пустой строке
                    Toast.makeText(MainActivity.this, R.string.no_user_input, Toast.LENGTH_LONG).show();
                        //всплывающееся окно появляется благодаря классу Toast
                        //необходимо обратиться также к статическому методу makeText, в котором нужно указать три параметра
                        //окно - MainActivity.this, на котором будет все изображено
                        //resld - текст, который увидит пользователь, обращаемся к необходимому тексту через R.string.
                        //длительность всплывающегося окна - Toast.LENGTH_LONG (примерно 3 секунды)
                        //.show показывает окно пользователю
                else {
                    //обращаемся к определенному сервису, где узнаем погоду в каждом городе
                    String city = user_field.getText().toString();   //в этой переменной будет хранится текст пользователя
                    String key = "9e0e7dd03f08578087dd1d6eba498108"; //здесь будет хранится ключ API
                    String url = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + key + "&units=metric&lang=ru";  //хранится сама ссылка

                    new GetUrlData().execute(url); //вызываем execute из класса AsyncTask
                }
            }
        });
    }

    //создаем класс, который наследует AsyncTask - возможность выполнения некого кода ассинхронно
    private class GetUrlData extends AsyncTask<String, String , String> {

        //реализуем метод onPreExecute, который срабатывает в тот момент, когда отправляем данные по определенному url-адресу
        protected void onPreExecute() {
            super.onPreExecute();             //обращаемся к этому же методу, только в родительском классе
            result_info.setText("Ожидайте...");  //обращаемся к установке текста
        }

        @Override
        protected String doInBackground(String... strings) {   //в данном методе получаем всю информацию из url-адреса
            HttpURLConnection connection = null;  //прописываем что именно будем это делать
            BufferedReader reader = null;

            try {
                URL url = new URL(strings[0]);  //передаем один параметр, получаем его из самого метода
                connection = (HttpURLConnection) url.openConnection(); //открываем само соединение
                connection.connect();

                //теперь будем считывать данные
                InputStream stream =  connection.getInputStream();  //позволяет получить полную информацию из url-адреса
                reader = new BufferedReader(new InputStreamReader(stream));

                //создаем строку с некоторыми особенными методами
                StringBuffer buffer = new StringBuffer();
                String line = "";  //создаем пустую строку

                while ((line = reader.readLine()) != null) //в переменную записываем обращение к методу, где считывается по одной линии, также проверяем, что считывается до тех пор пока текст есть
                    buffer.append(line).append("\n");   //добавляем к строке одну прочитанную линию и перенос на новую строку

                return buffer.toString();   //возвращаем buffer к обычной строке

            } catch (MalformedURLException e) {   //добавили исключения
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {   //чтобы метод был логично построен, добавляем finally, который будет прочтен в любом случае
                //здесь будем закрывать различные соединения, чтобы программа при работе не тормозила
                if (connection != null)
                    connection.disconnect();

                try {
                    if (reader != null)
                        reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            return null;  //чтобы программа не выдавала ошибку, нужно чтоб метод всегда что-то возвращал
        }

        @SuppressLint("SetTextI18n")
        @Override  //напишем метод, который после получения всех данных из url-адреса будет показывать их пользователю
        protected void onPostExecute(String result) {    //здесь принимаем одну строку, который показывает результат
            super.onPostExecute(result);

            try {
                JSONObject jsonObject = new JSONObject(result);  //через объект мы можем обращаться ко всем данным в JSONObject
                JSONObject weather = jsonObject.getJSONArray("weather").getJSONObject(0);
                result_info.setText("Состояние погоды: " + weather.getString("description") + System.lineSeparator() + System.lineSeparator() + "Температура: " + jsonObject.getJSONObject("main").getDouble("temp") + " ℃" + System.lineSeparator() + System.lineSeparator() + "Ощущается: " + jsonObject.getJSONObject("main").getDouble("feels_like") + " ℃" + System.lineSeparator() + System.lineSeparator() + "Максимум: " + jsonObject.getJSONObject("main").getDouble("temp_max") + " ℃" + System.lineSeparator() + System.lineSeparator() + "Минимум: " + jsonObject.getJSONObject("main").getDouble("temp_min") + " ℃");      //сразу выводим результат
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

    }
}